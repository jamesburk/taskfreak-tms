Please open the README.txt file from the install folder for information
on how to install TaskFreak! multi user
