<?php
/****************************************************************************\
* TaskFreak!                                                                 *
* multi user                                                                 *
******************************************************************************
* Version: 0.6.3                                                             *
* Authors: Stan Ozier <taskfreak@gmail.com>                                  *
* License:  http://www.gnu.org/licenses/gpl.txt (GPL)                        *
\****************************************************************************/

// -------------- VIEW PANEL --------------------------------------------------
?>
	  <div id="fview" style="display:none">
		<div id="fviewload" style="display:block"><img src="skins/<?php echo FRK_SKIN_FOLDER; ?>/images/load.gif" border="0" /></div>
		<div id="fviewcontent" style="display:none">
		</div>
	  </div>
